# 原序：原字标志提案

用户的最新指令明确排除蓝色：沿用现有雾白、深墨、赭橙，以及已经接受的名字和中英字标，只重新设计方折符号。

本次由 Agent 选择「原字成标」方向作具体提案：从可读的“原”字建立识别，让粗细和弧度参与轮廓，赭橙落在右下笔画。它是基于前一轮字形草图的深化，不代表用户已经选定。原字笔画为本轮绘制的矢量路径。

品类是企业知识工具；标志用于导航、登录入口、应用图标和页签。北极星：第一眼记得住“原”，缩小后仍能看清字形。沿用此前看过的专业知识产品对清晰轮廓、紧凑组合和多背景适配的要求；本轮没有重新开展行业研究，也不依赖此前海洋动物的色彩或造型。

配色严格沿用当前品牌：雾白 `#F6F7F8`、深墨 `#20262E`、赭橙 `#B84A2A`；深底强调 `#F09A77`。中文和拉丁字标、六枚功能图标及品牌页框架沿用当前资产。字体许可随预览包附上。

本轮在独立目录制作完整应用预览及导出，以便看清新符号与现有品牌的关系。当前品牌包和产品页面仍是原版本；本提案不自动应用到产品。

- 预览：<http://127.0.0.1:3000/brand/explorations/yuanxu-letter/brandbook.html>。
- 公开资产：`web/public/brand/explorations/yuanxu-letter/`。
- 本目录 `source/` 包含独立生成、栅格导出与打包脚本，不增加运行依赖。
- 实际画面、局部、独立评审和资产检查位于本目录的 `previews/`、`proofs/`、`qa/`。

再生成：使用项目 Python 及现有 fonttools/brotli 环境，运行 `source/generate.py --font-license artifacts/rebrand/font-license.txt`；随后运行 `source/render.mjs --sharp-module <已有 sharp 路径>`；最后运行 `source/package.py --assets web/public/brand/explorations/yuanxu-letter --guide artifacts/rebrand/yuan-letter-v4/README.md --report artifacts/rebrand/yuan-letter-v4/qa/assets.json`。

检查重点：字形可读性，24/32px 下两处内白，16px 简化字形，图文组合是否有重复感，反白和单色的一致性，PNG 透明通道，遮罩安全范围，以及下载包中的图形是否一致。
